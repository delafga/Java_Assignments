import java.util.List;
import java.util.Arrays;

public class Main{
    public static void main(String[] args) {
        //String[] inputs = {"ITEM0001 x 1", "ITEM0013 x 2", "ITEM0022 x 1"};
        //String[] inputs = {"ITEM0013 x 4", "ITEM0022 x 1"};
        //String[] inputs = {"ITEM0013 x 4"};
        String[] inputs = {"ITEM0001 x 2", "ITEM0013 x 5", "ITEM0022 x 3"};
        App runApp = new App(new ItemRepositoryTestImpl(), new SalesPromotionRepositoryTestImpl());
        List<String> inputList = Arrays.asList(inputs);
        
        System.out.println(runApp.bestCharge(inputList)); 
    }
}